
/*Enums*/

var Commands  = {
    onLoadReferenceWebsites  : "onLoadReferenceWebsites",
    onClickReferenceWebsite  : "onClickReferenceWebsite"
};

/*Links*/

var GET  = {
    pData  : "pData",
};


var UIID  = {
    mReferenceWebsites  : "mReferenceWebsites",
};

var ReferenceWebsitesDataID  = {
	mIcon : "mIcon",
	mHeader : "mHeader",
	mBody : "mBody",
	mUrl : "mUrl",
};
