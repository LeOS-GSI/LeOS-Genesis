
/*Strings*/

var strings  = {
    emptyString  : "",
};
