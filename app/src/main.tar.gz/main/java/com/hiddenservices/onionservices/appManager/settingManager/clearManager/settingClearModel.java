package com.hiddenservices.onionservices.appManager.settingManager.clearManager;

import com.hiddenservices.onionservices.eventObserver;

class settingClearModel {
    /*Variable Declaration*/

    private eventObserver.eventListener mEvent;

    /*Initializations*/

    settingClearModel(eventObserver.eventListener mEvent) {
        this.mEvent = mEvent;
    }

    /*Helper Methods*/


}
