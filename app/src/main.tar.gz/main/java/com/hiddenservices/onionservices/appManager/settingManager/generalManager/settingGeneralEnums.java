package com.hiddenservices.onionservices.appManager.settingManager.generalManager;

class settingGeneralEnums {
    /*History Manager*/
    public enum eGeneralModel {
        M_FULL_SCREEN_BROWSING, M_SELECT_THEME, M_URL_NEW_TAB
    }

    public enum eGeneralViewController {
        M_SET_THEME, M_RESET_THEME, M_UPDATE_THEME_BLOCKER
    }

    public enum eGeneralViewCallback {
        M_RESET_THEME_INVOKED_BACK
    }
}