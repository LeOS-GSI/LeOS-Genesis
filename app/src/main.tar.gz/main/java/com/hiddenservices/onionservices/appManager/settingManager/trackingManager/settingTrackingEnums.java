package com.hiddenservices.onionservices.appManager.settingManager.trackingManager;

class settingTrackingEnums {
    /*History Manager*/
    public enum eTrackingModel {
        M_SET_TRACKING_PROTECTION
    }

    public enum eTrackingViewController {
        M_SET_TRACKING_STATUS
    }

}