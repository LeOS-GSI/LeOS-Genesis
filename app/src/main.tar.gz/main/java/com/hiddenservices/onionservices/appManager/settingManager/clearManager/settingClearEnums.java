package com.hiddenservices.onionservices.appManager.settingManager.clearManager;

class settingClearEnums {
    /*History Manager*/
    public enum eClearModel {
    }

    public enum eClearViewController {
        M_CHECK_INVOKE
    }

}