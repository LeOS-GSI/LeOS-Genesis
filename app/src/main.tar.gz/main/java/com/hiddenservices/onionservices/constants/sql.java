package com.hiddenservices.onionservices.constants;

public class sql {
    /*HISTORY*/

    public static final String SQL_CLEAR_HISTORY = "delete from history where 1";
    public static final String SQL_CLEAR_BOOKMARK = "delete from bookmark where 1";
    public static final String SQL_CLEAR_TAB = "delete from tab where 1";


}
