package com.hiddenservices.onionservices.appManager.settingManager.logManager;

class settingLogEnums {
    /* Log Model */

    public enum eLogModel {
        M_SWITCH_LOG_VIEW
    }

    /* Log View Controller */

    public enum eLogViewController {
        M_INIT_VIEW, M_toggle_LOG_VIEW
    }
}