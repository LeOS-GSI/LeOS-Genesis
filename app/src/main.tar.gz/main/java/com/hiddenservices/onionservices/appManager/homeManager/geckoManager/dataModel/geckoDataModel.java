package com.hiddenservices.onionservices.appManager.homeManager.geckoManager.dataModel;

public class geckoDataModel {
    public int mCurrentURL_ID = -1;
    public boolean mFullScreenStatus = false;

    public String mTheme = null;
    public String mCurrentURL = "about:blank";
    public String mSessionID;
    public String mCurrentTitle = "loading";
}
