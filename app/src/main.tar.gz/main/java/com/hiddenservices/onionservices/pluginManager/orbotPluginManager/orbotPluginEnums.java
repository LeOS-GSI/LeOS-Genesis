package com.hiddenservices.onionservices.pluginManager.orbotPluginManager;

public class orbotPluginEnums {
    /*Orbot Log Manager*/
    public enum eLogManager {
        M_GET_CLEANED_LOGS
    }

    public enum eProxyManager {
        M_INIT_PROXY, M_INIT_PRIVACY
    }
}