package com.hiddenservices.onionservices.appManager.settingManager.proxyStatusManager;

public class proxyStatusEnums {
    /*Settings Manager*/
    public enum eProxyStatusViewCommands {
        M_INIT_VIEWS
    }

    public enum eProxyStatusModelCommands {
    }
}