package com.hiddenservices.onionservices.appManager.settingManager.settingHomeManager;

public class settingHomeEnums {
    /*History Manager*/
    public enum eHomeModel {
    }

    public enum eHomeViewController {
        M_INIT
    }

}