package com.hiddenservices.onionservices.appManager.bridgeManager;

public class bridgeEnums {
    /*Settings Manager*/
    public enum eBridgeViewCommands {
        M_INIT_VIEWS, M_ENABLE_CUSTOM_BRIDGE
    }

    public enum eBridgeModelCommands {
        M_REQUEST_BRIDGE, M_CUSTOM_BRIDGE, M_MEEK_BRIDGE, M_OBFS_CHECK, M_SNOWFLAKES_BRIDGE
    }

}