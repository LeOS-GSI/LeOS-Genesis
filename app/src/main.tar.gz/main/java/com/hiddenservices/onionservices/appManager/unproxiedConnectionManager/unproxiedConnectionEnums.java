package com.hiddenservices.onionservices.appManager.unproxiedConnectionManager;

class unproxiedConnectionEnums {
    /*History Manager*/
    public enum eAdvertClientCallback {
        M_UPDATE_PROGRESSBAR
    }

    public enum eAdvertViewController {
        M_UPDATE_PROGRESSBAR, M_UPDATE_HEADER
    }
}