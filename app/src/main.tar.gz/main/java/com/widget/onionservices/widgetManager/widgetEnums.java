package com.widget.onionservices.widgetManager;

public class widgetEnums {
    /*Widget Manager*/

    public enum eWidgetViewController {
        M_INIT
    }

    public enum eModelViewController {
        M_ON_RECIEVE
    }

    /*Widget Manager Callback*/

    public enum eWidgetControllerCallback {
        M_UPDATE, M_DELETE, M_OPTION_CHANGE, M_RESTORE
    }

}