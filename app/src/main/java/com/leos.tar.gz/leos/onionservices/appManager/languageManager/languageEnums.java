package com.hiddenservices.onionservices.appManager.languageManager;

class languageEnums {
    /*History Manager*/
    public enum eLanguageModel {
        M_SUPPORTED_LANGUAGE, M_ACTIVE_LANGUAGE
    }

    public enum eLanguagevViewController {
        M_UPDATE_BLOCKER
    }

    public enum eLanguageAdapterCallback {
        M_UPDATE_LANGUAGE, M_DISABLE_VIEW_CLICK, M_ENABLE_VIEW_CLICK, M_SYSTEM_LANGUAGE_SUPPORT_INFO
    }
}