package com.hiddenservices.onionservices.appManager.settingManager.searchEngineManager;

class settingSearchEnums {
    /*History Manager*/
    public enum eSearchModel {
        M_SET_SEARCH_ENGINE, M_SET_SEARCH_HISTORY, M_SET_SEARCH_SUGGESTION_STATUS
    }

    public enum eSearchViewController {
        M_INIT_SEARCH_ENGINE, M_RESET_SEARCH_ENGINE
    }

}