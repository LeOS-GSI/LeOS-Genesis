package com.hiddenservices.onionservices.appManager.settingManager.accessibilityManager;

class settingAccessibilityEnums {
    /*History Manager*/
    public enum eAccessibilityModel {
        M_UPDATE_SAMPLE_TEXT, M_UPDATE_PERCENTAGE
    }

    public enum eAccessibilityViewController {
        M_ZOOM_SETTING, M_VOICE_INPUT_SETTING
    }

}