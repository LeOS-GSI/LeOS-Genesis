package com.hiddenservices.onionservices.appManager.settingManager.proxyStatusManager;

import com.hiddenservices.onionservices.eventObserver;

class proxyStatusModel {
    /*Variable Declaration*/

    private eventObserver.eventListener mEvent;

    /*Initializations*/

    proxyStatusModel(eventObserver.eventListener mEvent) {
        this.mEvent = mEvent;
    }

}
