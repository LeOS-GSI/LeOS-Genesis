package com.hiddenservices.onionservices.appManager.settingManager.advanceManager;

class settingAdvanceEnums {
    /*History Manager*/
    public enum eAdvanceModel {
        M_RESTORE_TAB, M_SHOW_IMAGE, M_SHOW_TAB_GRID, M_SHOW_WEB_FONTS, M_BACKGROUND_MUSIC, M_TOOLBAR_THEME
    }

    public enum eAdvanceViewController {
        M_CLEAR_IMAGE, M_SET_IMAGE, M_CLEAR_GRID, M_SET_GRID
    }

}