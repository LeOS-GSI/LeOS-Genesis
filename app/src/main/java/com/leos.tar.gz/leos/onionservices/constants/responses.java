package com.hiddenservices.onionservices.constants;

public class responses {
    /*Notification Manager Manager*/
    public static final String BOOKMARK_SETTING_CONTROLLER_SHOW_SUCCESS_ALERT = "BOOKMARK_SETTING_CONTROLLER_SHOW_SUCCESS_ALERT";
    public static final String BOOKMARK_SETTING_CONTROLLER_SHOW_DELETE_ALERT = "BOOKMARK_SETTING_CONTROLLER_SHOW_DELETE_ALERT";

}

