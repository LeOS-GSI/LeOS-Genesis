package com.hiddenservices.onionservices.appManager.settingManager.notificationManager;

class settingNotificationEnums {
    /*History Manager*/
    public enum eNotificationModel {
        M_UPDATE_LOCAL_NOTIFICATION
    }

    public enum eNotificationViewController {

    }

}