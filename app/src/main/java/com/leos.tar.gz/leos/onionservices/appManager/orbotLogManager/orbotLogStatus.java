package com.hiddenservices.onionservices.appManager.orbotLogManager;

public class orbotLogStatus {

    public static boolean sUIInteracted = false;
    public static int sScrollPosition = -1;
    public static int sOrientation = -1;
}
