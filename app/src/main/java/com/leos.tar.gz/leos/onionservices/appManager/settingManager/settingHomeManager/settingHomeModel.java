package com.hiddenservices.onionservices.appManager.settingManager.settingHomeManager;

import com.hiddenservices.onionservices.eventObserver;

public class settingHomeModel {
    /*Variable Declaration*/

    private eventObserver.eventListener mEvent;

    /*Initializations*/

    settingHomeModel(eventObserver.eventListener mEvent) {
        this.mEvent = mEvent;
    }

}
