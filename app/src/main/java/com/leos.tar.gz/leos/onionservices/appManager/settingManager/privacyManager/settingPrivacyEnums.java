package com.hiddenservices.onionservices.appManager.settingManager.privacyManager;

class settingPrivacyEnums {
    /*Privacy Manager*/
    public enum ePrivacyModel {
        M_SET_JAVASCRIPT, M_SET_POPUP, M_SET_DONOT_TRACK, M_SET_COOKIES, M_SET_CLEAR_PRIVATE_DATA
    }

    public enum ePrivacyViewController {
        M_SET_COOKIE_STATUS
    }

}