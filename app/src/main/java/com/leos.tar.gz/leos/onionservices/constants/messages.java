package com.hiddenservices.onionservices.constants;

public class messages {
    /*POST MESSAGES KEYS*/

    public final static int MESSAGE_UPDATE_LOADING_TEXT = 1;
    public final static int MESSAGE_ON_URL_LOAD = 2;
    public final static int MESSAGE_PROGRESSBAR_VALIDATE = 3;
}
